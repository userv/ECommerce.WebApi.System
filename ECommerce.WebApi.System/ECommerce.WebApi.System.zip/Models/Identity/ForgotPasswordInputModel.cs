﻿namespace ECommerce.WebApi.System.Models.Identity
{
    public class ForgotPasswordInputModel
    {
        public string Email { get; set; }
    }
}
