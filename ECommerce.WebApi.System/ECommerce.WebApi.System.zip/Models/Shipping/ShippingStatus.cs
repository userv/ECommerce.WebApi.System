﻿namespace ECommerce.WebApi.System.Models.Shipping
{
    public enum ShippingStatus
    {
        Pending = 1,
        Shipped = 2,
        Delivered = 3
    }
}
