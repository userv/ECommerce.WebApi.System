﻿namespace ECommerce.WebApi.System.Models.Shipping
{
    public enum ShippingMethod
    {
        Standard = 1,
        Express = 2

    }
}
