﻿namespace ECommerce.WebApi.System.Models.Orders
{
    public class OrderItemInputModel
    {
        public int ProductId { get; set; }
        public int Quantity { get; set; }
    }
}
