﻿namespace ECommerce.WebApi.System.Models.Categories
{
    public class CategoryInputModel
    {
        public string Name { get; set; } = default!;
        public string Description { get; set; } = default!;
    }
}
